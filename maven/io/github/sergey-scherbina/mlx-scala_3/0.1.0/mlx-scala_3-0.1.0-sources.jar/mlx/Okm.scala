package mlx

import java.lang.foreign.*
import java.lang.foreign.ValueLayout.*
import java.lang.invoke.MethodHandle

/** THE FLAT LAYER on the JVM: libokm's functions through FFM. A handle (a C pointer) is a `long` on both sides — the
 * same register in the C ABI — so a call allocates nothing; int arrays go through a buffer of the thread's own */
private[mlx] object Okm:
  /** -Dokm.lib=<libokm.dylib>, else MLX_SCALA_LIB=<its directory> */
  private val lib = SymbolLookup.libraryLookup(java.nio.file.Path.of(sys.props.get("okm.lib")
    .orElse(sys.env.get("MLX_SCALA_LIB").map(_ + "/libokm.dylib"))
    .getOrElse(sys.error("libokm not found: set -Dokm.lib=<libokm.dylib> or MLX_SCALA_LIB=<its directory>"))),
    Arena.global())
  private val linker = Linker.nativeLinker()
  private def fn(name: String, ret: MemoryLayout | Null, args: MemoryLayout*): MethodHandle =
    val d = if ret == null then FunctionDescriptor.ofVoid(args*) else FunctionDescriptor.of(ret, args*)
    linker.downcallHandle(lib.find(name).orElseThrow(), d)

  private val J = JAVA_LONG
  private val I = JAVA_INT
  private val F = JAVA_FLOAT

  /** four int arrays of 16 and two words per thread: an op's shapes, start/stop, and the out-parameters of a load */
  private val scratch = ThreadLocal.withInitial(() => Arena.global().allocate(4 * 16 * 4 + 16, 8))
  private inline def ints(slot: Int, xs: Array[Int]): Long =
    val s = scratch.get()
    val base = slot * 64L
    var i = 0
    while i < xs.length do
      s.set(JAVA_INT, base + i * 4L, xs(i)); i += 1
    s.address() + base

  private val hInit = fn("okm_init", I)
  private val hUseCpu = fn("okm_use_cpu", null, I)
  private val hError = fn("okm_error", J)
  private val hFree = fn("okm_free", null, J)
  private val hRetain = fn("okm_retain", J, J)
  private val hNdim = fn("okm_ndim", I, J)
  private val hDim = fn("okm_dim", I, J, I)
  private val hDtype = fn("okm_dtype", I, J)
  private val hEval = fn("okm_eval", I, J)
  private val hAsyncEval = fn("okm_async_eval", I, J)
  private val hEvalAll = fn("okm_eval_all", I, J, I)
  private val hItemI32 = fn("okm_item_i32", I, J)
  private val hToI32 = fn("okm_to_i32", I, J, J, I)
  private val hCopyI32 = fn("okm_copy_i32", I, J, J, I)
  private val hItemF32 = fn("okm_item_f32", F, J)
  private val hFromI32 = fn("okm_from_i32", J, J, J, I)
  private val hFromF32 = fn("okm_from_f32", J, J, J, I)
  private val hValueAndGrad = fn("okm_value_and_grad", I, J, J, J, I, J, I, J, J)
  private val hToF32 = fn("okm_to_f32", I, J, J, I)
  private val hScalarF32 = fn("okm_scalar_f32", J, F)
  private val hAdd = fn("okm_add", J, J, J)
  private val hMultiply = fn("okm_multiply", J, J, J)
  private val hMatmul = fn("okm_matmul", J, J, J)
  private val hSigmoid = fn("okm_sigmoid", J, J)
  private val hAstype = fn("okm_astype", J, J, I)
  private val hReshape = fn("okm_reshape", J, J, J, I)
  private val hTranspose = fn("okm_transpose", J, J, J, I)
  private val hArgmax = fn("okm_argmax", J, J, I)
  private val hSoftmax = fn("okm_softmax", J, J, I)
  private val hTake = fn("okm_take", J, J, J, I)
  private val hSlice = fn("okm_slice", J, J, J, J, I)
  private val hSliceUpdate = fn("okm_slice_update", J, J, J, J, J, I)
  private val hConcatenate = fn("okm_concatenate", J, J, I, I)
  private val hZeros = fn("okm_zeros", J, J, I, I)
  private val hQmm = fn("okm_quantized_matmul", J, J, J, J, J, I, I, I)
  private val hSubtract = fn("okm_subtract", J, J, J)
  private val hSilu = fn("okm_silu", J, J)
  private val hCumsum = fn("okm_cumsum", J, J, I)
  private val hGreater = fn("okm_greater", J, J, J)
  private val hWhere = fn("okm_where", J, J, J, J)
  private val hCategorical = fn("okm_categorical", J, J, I)
  private val hSeed = fn("okm_random_seed", I, J)
  private val hSwiglu = fn("okm_swiglu", J, J, J)
  private val hPreciseSwiglu = fn("okm_precise_swiglu", J, J, J, J)
  private val hComputeG = fn("okm_compute_g", J, J, J, J)
  private val hDivide = fn("okm_divide", J, J, J)
  private val hFloorDivide = fn("okm_floor_divide", J, J, J)
  private val hExp = fn("okm_exp", J, J)
  private val hNegative = fn("okm_negative", J, J)
  private val hLog = fn("okm_log", J, J)
  private val hSqrt = fn("okm_sqrt", J, J)
  private val hLogsumexp = fn("okm_logsumexp", J, J, I, I)
  private val hLogaddexp = fn("okm_logaddexp", J, J, J)
  private val hContiguous = fn("okm_contiguous", J, J)
  private val hSum = fn("okm_sum", J, J, I, I)
  private val hMax = fn("okm_max", J, J, I, I)
  private val hMaximum = fn("okm_maximum", J, J, J)
  private val hExpandDims = fn("okm_expand_dims", J, J, I)
  private val hSqueeze = fn("okm_squeeze", J, J, I)
  private val hArgpartition = fn("okm_argpartition", J, J, I, I)
  private val hArgsort = fn("okm_argsort", J, J, I)
  private val hTakeAlong = fn("okm_take_along", J, J, J, I)
  private val hConv1d = fn("okm_conv1d", J, J, J, I, I, I, I)
  private val hConv2d = fn("okm_conv2d", J, J, J, I, I)
  private val hScalarI32 = fn("okm_scalar_i32", J, I)
  private val hGatherQmm = fn("okm_gather_qmm", J, J, J, J, J, J, I, I, I, I)
  private val hKernelNew = fn("okm_kernel_new", J, J, J, I, J, I, J, J)
  private val hKernelApply = fn("okm_kernel_apply", I, J, J, I, J, J, J, I, J, J, J, J, J, I, J)
  private val hDequantize = fn("okm_dequantize", J, J, J, J, I, I)
  private val hQuantize = fn("okm_quantize", I, J, I, I, J)
  private val hRmsNorm = fn("okm_rms_norm", J, J, J, F)
  private val hRope = fn("okm_rope", J, J, I, I, F, F, I)
  private val hSdpa = fn("okm_sdpa", J, J, J, J, F, I)
  private val hLoadOpen = fn("okm_load_open", J, J)
  private val hMapTensor = fn("okm_map_tensor", J, J, J, J, I, J, I, I)
  private val hBuffer = fn("okm_buffer", J, J, I, I)
  private val hPressure = fn("okm_memory_pressure", I)
  private val hFreePercent = fn("okm_memory_free_percent", I)
  private val hRoom = fn("okm_memory_room", J)
  private val hOpenFd = fn("okm_open_fd", I, J)
  private val hCloseFd = fn("okm_close_fd", I, I)
  private val hReadInto = fn("okm_read_into", I, I, J, J, J, J)
  private val hLoadNext = fn("okm_load_next", I, J, J, J)
  private val hLoadClose = fn("okm_load_close", null, J)
  private val hSave = fn("okm_save_safetensors", I, J, J, J, I, J, J, I)
  private val hActive = fn("okm_active_memory", J)
  private val hClearCache = fn("okm_clear_cache", I)
  private val hCacheMemory = fn("okm_cache_memory", J)
  private val hSetCacheLimit = fn("okm_set_cache_limit", J, J)
  private val hExportDot = fn("okm_export_dot", I, J, J)
  private val hPeak = fn("okm_peak_memory", J)

  def init(): Int = hInit.invokeExact()
  def error(): String =
    val p: Long = hError.invokeExact()
    MemorySegment.ofAddress(p).reinterpret(1024).getString(0)
  def free(a: Long): Unit = hFree.invokeExact(a)
  def useCpu(yes: Boolean): Unit = hUseCpu.invokeExact(if yes then 1 else 0)
  def retain(a: Long): Long = hRetain.invokeExact(a)
  def ndim(a: Long): Int = hNdim.invokeExact(a)
  def dim(a: Long, i: Int): Int = hDim.invokeExact(a, i)
  def dtype(a: Long): Int = hDtype.invokeExact(a)
  def eval(a: Long): Int = hEval.invokeExact(a)
  def asyncEval(a: Long): Int = hAsyncEval.invokeExact(a)
  def evalAll(as: Array[Long]): Int =
    val arena = Arena.ofConfined()
    try
      val p = arena.allocateFrom(JAVA_LONG, as*)
      val r: Int = hEvalAll.invokeExact(p.address(), as.length)
      r
    finally arena.close()
  def itemI32(a: Long): Int = hItemI32.invokeExact(a)
  def toI32(a: Long, n: Int): Array[Int] = i32(a, n, copy = false)
  def copyI32(a: Long, n: Int): Array[Int] = i32(a, n, copy = true)
  private def i32(a: Long, n: Int, copy: Boolean): Array[Int] =
    val arena = Arena.ofConfined()
    try
      val out = arena.allocate(JAVA_INT, math.max(n, 1).toLong)
      val got: Int =
        if copy then hCopyI32.invokeExact(a, out.address(), n) else hToI32.invokeExact(a, out.address(), n)
      if got < 0 then null else out.asSlice(0, 4L * math.min(got, n)).toArray(JAVA_INT)
    finally arena.close()
  def itemF32(a: Long): Float = hItemF32.invokeExact(a)
  def fromI32(data: Array[Int], shape: Array[Int]): Long =
    val arena = Arena.ofConfined()
    try
      val d = arena.allocateFrom(JAVA_INT, data*)
      val r: Long = hFromI32.invokeExact(d.address(), ints(0, shape), shape.length)
      r
    finally arena.close()
  def fromF32(data: Array[Float], shape: Array[Int]): Long =
    val arena = Arena.ofConfined()
    try
      val d = arena.allocateFrom(JAVA_FLOAT, data*)
      val r: Long = hFromF32.invokeExact(d.address(), ints(0, shape), shape.length)
      r
    finally arena.close()
  def toF32(a: Long, n: Int): Array[Float] =
    val arena = Arena.ofConfined()
    try
      val out = arena.allocate(JAVA_FLOAT, math.max(n, 1).toLong)
      val got: Int = hToF32.invokeExact(a, out.address(), n)
      if got < 0 then null else out.asSlice(0, 4L * math.min(got, n)).toArray(JAVA_FLOAT)
    finally arena.close()
  /** autograd: `okm_value_and_grad` with the callback stub below; (the value, the gradients), or null */
  def valueAndGrad(id: Long, ins: Array[Long], argnums: Array[Int]): (Long, Array[Long]) | Null =
    val arena = Arena.ofConfined()
    try
      val i = arena.allocateFrom(JAVA_LONG, ins*)
      val a = arena.allocateFrom(JAVA_INT, argnums*)
      val v = arena.allocate(JAVA_LONG)
      val g = arena.allocate(JAVA_LONG, math.max(1, argnums.length).toLong)
      val rc: Int = hValueAndGrad.invokeExact(callbackStub.address(), id, i.address(), ins.length, a.address(),
        argnums.length, v.address(), g.address())
      if rc != 0 then null else (v.get(JAVA_LONG, 0), g.asSlice(0, 8L * argnums.length).toArray(JAVA_LONG))
    finally arena.close()
  /** the C callback `okm_fn(id, ins, nin, outs, maxout)`: the function registered under `id` (Grad), its inputs read,
   * its outputs written; -1 if it throws (an exception must not cross into C) */
  final class Callback:
    def call(id: Long, ins: MemorySegment, nin: Int, outs: MemorySegment, maxout: Int): Int =
      try
        val in = ins.reinterpret(8L * nin)
        val out = Grad.call(id, Array.tabulate(nin)(k => in.getAtIndex(JAVA_LONG, k.toLong)))
        if out.length > maxout then -1
        else
          val o = outs.reinterpret(8L * maxout)
          for k <- out.indices do o.setAtIndex(JAVA_LONG, k.toLong, out(k))
          out.length
      catch case e: Throwable =>
        System.err.println(s"mlx autograd: the function threw $e")
        -1
  private lazy val callbackStub: MemorySegment =
    val mt = java.lang.invoke.MethodType.methodType(classOf[Int], classOf[Long], classOf[MemorySegment], classOf[Int],
      classOf[MemorySegment], classOf[Int])
    val h = java.lang.invoke.MethodHandles.lookup().findVirtual(classOf[Callback], "call", mt).bindTo(Callback())
    linker.upcallStub(h, FunctionDescriptor.of(I, J, ADDRESS, I, ADDRESS, I), Arena.global())
  def scalarF32(v: Float): Long = hScalarF32.invokeExact(v)
  def add(a: Long, b: Long): Long = hAdd.invokeExact(a, b)
  def multiply(a: Long, b: Long): Long = hMultiply.invokeExact(a, b)
  def matmul(a: Long, b: Long): Long = hMatmul.invokeExact(a, b)
  def sigmoid(a: Long): Long = hSigmoid.invokeExact(a)
  def astype(a: Long, dtype: Int): Long = hAstype.invokeExact(a, dtype)
  def reshape(a: Long, shape: Array[Int]): Long = hReshape.invokeExact(a, ints(0, shape), shape.length)
  def transpose(a: Long, axes: Array[Int]): Long = hTranspose.invokeExact(a, ints(0, axes), axes.length)
  def argmax(a: Long, axis: Int): Long = hArgmax.invokeExact(a, axis)
  def softmax(a: Long, axis: Int): Long = hSoftmax.invokeExact(a, axis)
  def take(a: Long, idx: Long, axis: Int): Long = hTake.invokeExact(a, idx, axis)
  def slice(a: Long, start: Array[Int], stop: Array[Int]): Long =
    hSlice.invokeExact(a, ints(0, start), ints(1, stop), start.length)
  def sliceUpdate(src: Long, upd: Long, start: Array[Int], stop: Array[Int]): Long =
    hSliceUpdate.invokeExact(src, upd, ints(0, start), ints(1, stop), start.length)
  def concatenate(as: Array[Long], axis: Int): Long =
    if as.length > 16 then
      // more than the scratch holds (a sequence's steps): a buffer of their own
      val arena = Arena.ofConfined()
      try
        val p = arena.allocateFrom(JAVA_LONG, as*)
        val r: Long = hConcatenate.invokeExact(p.address(), as.length, axis)
        r
      finally arena.close()
    else
      val s = scratch.get()
      // handles in slots 2..3 (16 words: 128 bytes from byte 128)
      var i = 0
      while i < as.length do
        s.set(JAVA_LONG, 128L + i * 8L, as(i)); i += 1
      hConcatenate.invokeExact(s.address() + 128L, as.length, axis)
  def zeros(shape: Array[Int], dtype: Int): Long = hZeros.invokeExact(ints(0, shape), shape.length, dtype)
  def quantizedMatmul(x: Long, w: Long, scales: Long, biases: Long, transpose: Boolean, groupSize: Int, bits: Int)
      : Long = hQmm.invokeExact(x, w, scales, biases, if transpose then 1 else 0, groupSize, bits)
  def dequantize(w: Long, scales: Long, biases: Long, groupSize: Int, bits: Int): Long =
    hDequantize.invokeExact(w, scales, biases, groupSize, bits)
  def quantize(w: Long, groupSize: Int, bits: Int): Array[Long] =
    val arena = Arena.ofConfined()
    try
      val outs = arena.allocate(JAVA_LONG, 3L)
      val e: Int = hQuantize.invokeExact(w, groupSize, bits, outs.address())
      if e != 0 then Array.empty else Array.tabulate(3)(i => outs.getAtIndex(JAVA_LONG, i.toLong))
    finally arena.close()
  def rmsNorm(x: Long, w: Long, eps: Float): Long = hRmsNorm.invokeExact(x, w, eps)
  def rope(x: Long, dims: Int, traditional: Boolean, base: Float, scale: Float, offset: Int): Long =
    hRope.invokeExact(x, dims, if traditional then 1 else 0, base, scale, offset)
  def sdpa(q: Long, k: Long, v: Long, scale: Float, causal: Boolean): Long =
    hSdpa.invokeExact(q, k, v, scale, if causal then 1 else 0)

  def subtract(a: Long, b: Long): Long = hSubtract.invokeExact(a, b)
  def silu(a: Long): Long = hSilu.invokeExact(a)
  def cumsum(a: Long, axis: Int): Long = hCumsum.invokeExact(a, axis)
  def greater(a: Long, b: Long): Long = hGreater.invokeExact(a, b)
  def where(c: Long, a: Long, b: Long): Long = hWhere.invokeExact(c, a, b)
  def categorical(logits: Long, axis: Int): Long = hCategorical.invokeExact(logits, axis)
  def randomSeed(seed: Long): Int = hSeed.invokeExact(seed)
  def swiglu(gate: Long, x: Long): Long = hSwiglu.invokeExact(gate, x)
  def preciseSwiglu(h: Long, gate: Long, x: Long): Long = hPreciseSwiglu.invokeExact(h, gate, x)
  def computeG(aLog: Long, a: Long, dtBias: Long): Long = hComputeG.invokeExact(aLog, a, dtBias)
  def divide(a: Long, b: Long): Long = hDivide.invokeExact(a, b)
  def floorDivide(a: Long, b: Long): Long = hFloorDivide.invokeExact(a, b)
  def exp(a: Long): Long = hExp.invokeExact(a)
  def negative(a: Long): Long = hNegative.invokeExact(a)
  def log(a: Long): Long = hLog.invokeExact(a)
  def sqrt(a: Long): Long = hSqrt.invokeExact(a)
  def logsumexp(a: Long, axis: Int, keepdims: Boolean): Long =
    hLogsumexp.invokeExact(a, axis, if keepdims then 1 else 0)
  def logaddexp(a: Long, b: Long): Long = hLogaddexp.invokeExact(a, b)
  def contiguous(a: Long): Long = hContiguous.invokeExact(a)
  def sum(a: Long, axis: Int, keepdims: Boolean): Long = hSum.invokeExact(a, axis, if keepdims then 1 else 0)
  def max(a: Long, axis: Int, keepdims: Boolean): Long = hMax.invokeExact(a, axis, if keepdims then 1 else 0)
  def maximum(a: Long, b: Long): Long = hMaximum.invokeExact(a, b)
  def expandDims(a: Long, axis: Int): Long = hExpandDims.invokeExact(a, axis)
  def squeeze(a: Long, axis: Int): Long = hSqueeze.invokeExact(a, axis)
  def argpartition(a: Long, kth: Int, axis: Int): Long = hArgpartition.invokeExact(a, kth, axis)
  def argsort(a: Long, axis: Int): Long = hArgsort.invokeExact(a, axis)
  def takeAlong(a: Long, idx: Long, axis: Int): Long = hTakeAlong.invokeExact(a, idx, axis)
  def conv1d(x: Long, w: Long, stride: Int, padding: Int, dilation: Int, groups: Int): Long =
    hConv1d.invokeExact(x, w, stride, padding, dilation, groups)
  def conv2d(x: Long, w: Long, stride: Int, padding: Int): Long = hConv2d.invokeExact(x, w, stride, padding)
  def scalarI32(v: Int): Long = hScalarI32.invokeExact(v)
  def gatherQmm(x: Long, w: Long, scales: Long, biases: Long, rhs: Long, transpose: Boolean, groupSize: Int,
      bits: Int, sorted: Boolean): Long =
    val (t, so) = (if transpose then 1 else 0, if sorted then 1 else 0)
    hGatherQmm.invokeExact(x, w, scales, biases, rhs, t, groupSize, bits, so)

  private def strings(arena: Arena, xs: Array[String]): MemorySegment =
    val p = arena.allocate(JAVA_LONG, xs.length.max(1).toLong)
    for (x, i) <- xs.zipWithIndex do p.setAtIndex(JAVA_LONG, i.toLong, arena.allocateFrom(x).address())
    p
  def kernelNew(name: String, inputs: Array[String], outputs: Array[String], source: String, header: String): Long =
    val arena = Arena.ofConfined()
    try
      val r: Long = hKernelNew.invokeExact(arena.allocateFrom(name).address(), strings(arena, inputs).address(),
        inputs.length, strings(arena, outputs).address(), outputs.length, arena.allocateFrom(source).address(),
        arena.allocateFrom(header).address())
      r
    finally arena.close()
  def kernelApply(kernel: Long, inputs: Array[Long], shapes: Array[Int], ndims: Array[Int], dtypes: Array[Int],
      grid: Array[Int], group: Array[Int], tNames: Array[String], tKinds: Array[Int], tValues: Array[Int])
      : Array[Long] =
    val arena = Arena.ofConfined()
    try
      def ints(xs: Array[Int]) = arena.allocateFrom(JAVA_INT, (if xs.isEmpty then Array(0) else xs)*).address()
      val outs = arena.allocate(JAVA_LONG, ndims.length.max(1).toLong)
      val in = arena.allocateFrom(JAVA_LONG, inputs*)
      val e: Int = hKernelApply.invokeExact(kernel, in.address(), inputs.length, ints(shapes), ints(ndims),
        ints(dtypes), ndims.length, ints(grid), ints(group), strings(arena, tNames).address(), ints(tKinds),
        ints(tValues), tNames.length, outs.address())
      if e != 0 then Array.empty else Array.tabulate(ndims.length)(i => outs.getAtIndex(JAVA_LONG, i.toLong))
    finally arena.close()

  def mapTensor(path: String, offset: Long, nbytes: Long, dtype: Int, shape: Array[Int], advise: Boolean): Long =
    val arena = Arena.ofConfined()
    try
      val p = arena.allocateFrom(path)
      val r: Long = hMapTensor.invokeExact(p.address(), offset, nbytes, dtype, ints(0, shape), shape.length,
        if advise then 1 else 0)
      r
    finally arena.close()
  def memoryPressure(): Int = hPressure.invokeExact()
  def memoryFreePercent(): Int = hFreePercent.invokeExact()
  def memoryRoom(): Long = hRoom.invokeExact()
  def buffer(shape: Array[Int], dtype: Int): Long = hBuffer.invokeExact(ints(0, shape), shape.length, dtype)
  def openFd(path: String): Int =
    val arena = Arena.ofConfined()
    try
      val r: Int = hOpenFd.invokeExact(arena.allocateFrom(path).address())
      r
    finally arena.close()
  def closeFd(fd: Int): Int = hCloseFd.invokeExact(fd)
  def readInto(fd: Int, dst: Long, dstOffset: Long, fileOffset: Long, n: Long): Int =
    hReadInto.invokeExact(fd, dst, dstOffset, fileOffset, n)
  def loadOpen(path: String): Long =
    val arena = Arena.ofConfined()
    try
      val p = arena.allocateFrom(path)
      val r: Long = hLoadOpen.invokeExact(p.address())
      r
    finally arena.close()
  /** the next tensor of an open file: its name and handle, or null at the end */
  def loadNext(file: Long): (String, Long) | Null =
    val s = scratch.get()
    val at = 4 * 16 * 4L
    val got: Int = hLoadNext.invokeExact(file, s.address() + at, s.address() + at + 8)
    if got == 0 then null
    else
      val key = MemorySegment.ofAddress(s.get(JAVA_LONG, at)).reinterpret(4096).getString(0)
      (key, s.get(JAVA_LONG, at + 8))
  def loadClose(file: Long): Unit = hLoadClose.invokeExact(file)
  def saveSafetensors(path: String, names: Array[String], arrays: Array[Long], keys: Array[String],
      values: Array[String]): Int =
    val arena = Arena.ofConfined()
    try
      val as = arena.allocateFrom(JAVA_LONG, (if arrays.isEmpty then Array(0L) else arrays)*)
      val r: Int = hSave.invokeExact(arena.allocateFrom(path).address(), strings(arena, names).address(), as.address(),
        names.length, strings(arena, keys).address(), strings(arena, values).address(), keys.length)
      r
    finally arena.close()
  def activeMemory(): Long = hActive.invokeExact()
  def clearCache(): Int = hClearCache.invokeExact()
  def cacheMemory(): Long = hCacheMemory.invokeExact()
  def setCacheLimit(limit: Long): Long = hSetCacheLimit.invokeExact(limit)
  def exportDot(a: Long, path: String): Int =
    val arena = Arena.ofConfined()
    try
      val r: Int = hExportDot.invokeExact(a, arena.allocateFrom(path).address())
      r
    finally arena.close()
  def peakMemory(): Long = hPeak.invokeExact()
